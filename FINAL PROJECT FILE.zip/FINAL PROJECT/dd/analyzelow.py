
import pandas as pd
from app2 import calculate_payout

# Define the combinations
districts = ["Ahmadnagar", "Akola", "Amravati", "Aurangabad", "Bid", "Buldana", "Dhule", "Hingoli", "Jalgaon", "Jalna", "Kolhapur", "Latur", "Nanded", "Nandurbar", "Nashik", "Osmanabad", "Palghar", "Parbhani", "Pune", "Raigarh", "Ratnagiri", "Sangli", "Satara", "Sindhudurg", "Solapur", "Thane", "Washim"]
crops = ['Pomegranate', 'Mango']
seasons = ['Kharif', 'Rabi']
years = range(2020, 2024)
area = 1.0  # or any fixed area you want to test with

results = []

for district in districts:
    for crop in crops:
        for season in seasons:
            for year in years:
                try:
                    result = calculate_payout(district, season, year, crop, area)
                    if result['avg_percent'] < 50:
                        results.append({
                            'district': district,
                            'crop': crop,
                            'season': season,
                            'year': year,
                            'avg_percent': result['avg_percent'],
                            'payout': result['payout']
                        })
                except Exception as e:
                    print(f"Error for {district}, {crop}, {season}, {year}: {e}")

# Convert to DataFrame and save
df = pd.DataFrame(results)
df.to_csv("payouts_below_50_all_districts.csv", index=False)
print("✅ Analysis complete. Results saved to payouts_below_50_all_districts.csv")
